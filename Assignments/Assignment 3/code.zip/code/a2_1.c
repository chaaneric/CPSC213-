int b;
int c;
int a[10];

c = 5;
b = c + 10; 
a[8] = 8;
a[4] = a[4] + 4;
a[c] = a[8] + b + a[b & 0x7];

