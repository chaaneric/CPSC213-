#include <stdlib.h>

int s=0;
int i;
int a[10] = {2,3,4,6,8,10,14,16,18,20};

void foo () {
  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;

  s += a[i];
  i++;
}
