#include <stdlib.h>
#include <stdio.h>

//
// A binary tree node with value and left and right children
struct Node {
  // TODO
};

//
// Insert node n into tree rooted at toNode
//
void insertNode (struct Node* toNode, struct Node* n) {
  // TODO
}

//
// Insert new node with specified value into tree rooted at toNode
//
void insert (struct Node* toNode, int value) {
  // TODO
}


//
// Print values of tree rooted at node in ascending order
//
void printInOrder (struct Node* node) {
  // TODO
}

//
// Create root node, insert some values, and print tree in order
//
int main (int argc, char* argv[]) {
  // TODO
}