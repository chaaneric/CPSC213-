int i   = 10;
int a[] = {10,-30,-12,4,8};
int s   = 0;

for (i = 0; i<5; i++)
  if (a[i] > 0)
    s += a[i];

