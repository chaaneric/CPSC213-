int add (int a, int b) {
  return a+b;
}

int s;

void foo () {
  s = add (1,2);
}
