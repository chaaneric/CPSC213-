void ping () {}

void foo () {
  ping ();
}
